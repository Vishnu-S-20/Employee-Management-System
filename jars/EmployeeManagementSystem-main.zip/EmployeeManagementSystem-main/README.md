# EmployeeManagementSystem
 Employee Management System in JavaFX
